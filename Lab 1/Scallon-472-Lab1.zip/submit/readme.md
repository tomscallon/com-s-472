# Com S 472: Lab 1
## ReadMe / Tom Scallon

Compile the program by running `javac WebSearch.java`.

Run the program as follows: `java WebSearch <directory> <strategy>` where
  - `directory` indicates an intranet directory
  - `strategy` indicates a search strategy, one of:
    - `breadth`
    - `depth`
    - `best`
    - `beam`
